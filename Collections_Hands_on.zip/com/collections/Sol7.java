package com.collections;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

public class Sol7
{
    TreeMap<String ,Integer> mapobj=new TreeMap<String,Integer>();
    public void Add(String Name,Integer PhoneNo)
    {
        mapobj.put(Name, PhoneNo);
    }

    public String getName(int PhoneNo)
    {
        return  mapobj.containsValue(PhoneNo) ?(mapobj.lastKey()) :"Phone Number not exists";
    }

    public int getPhone(String name)
    {
        return  mapobj.containsKey(name)? (mapobj.get(name)) :-1;
    }

    public void ListAll()
    {
        Set entrymap = mapobj.entrySet();
        Iterator it = entrymap.iterator();
        System.out.println("Contact Name,Phone Number");
        while (it.hasNext())
        {
            Map.Entry<String, Integer> me = (Map.Entry<String,Integer>) it.next();
            System.out.println(me.getKey() +"\t"+ me.getValue());


        }
    }

    public static void  main(String  args[])
    {
        Sol7 obj=new Sol7();
        obj.Add("Shubh", 923);
        obj.Add("Jimmy",8023023);
        obj.Add("Shubh",999);
        obj.ListAll();
        System.out.println(obj.getPhone("Jimmy"));
        System.out.println(obj.getName(923));
        System.out.println(obj.getName(999));
        System.out.println(obj.getPhone("KDM"));


    }





}
