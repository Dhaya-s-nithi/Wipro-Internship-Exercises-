package com.collections;
import java.util.*;

public class Sol5

    {
        HashMap<String,String > mapobj=new HashMap<>();
        public HashMap<String, String> saveCountryCapital(String  countryName, String capital)
        {
            mapobj.put(countryName, capital);
            return mapobj;

        }

        public ArrayList<String> toArrayCapitalName()
        {
            ArrayList<String> list = new ArrayList<>();
            Set entrymap = mapobj.entrySet();
            Iterator it = entrymap.iterator();
            while (it.hasNext()) {
                Map.Entry<String, String> me = (Map.Entry<String, String>) it.next();
                list.add(me.getValue());

            }
            return list;

        }

        public  static  void  main(String args[])
        {
            Sol5 obj=new Sol5();
            System.out.println(obj.saveCountryCapital("India","New Delhi"));
            System.out.println(obj.saveCountryCapital("Russia","Moscow"));
            System.out.println(obj.saveCountryCapital("Israel","Istanbul"));
            System.out.println((obj.toArrayCapitalName()));
        }
    }





