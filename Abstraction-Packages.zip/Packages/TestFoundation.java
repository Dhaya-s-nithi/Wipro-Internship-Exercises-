import test.Foundation;
public class TestFoundation {
    public static void main(String[] args) {
        Foundation fn = new Foundation();
        fn.var4 = 4;
        System.out.println(fn.var4);
    }
}
