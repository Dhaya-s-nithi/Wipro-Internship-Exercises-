class ICICIBank extends GeneralBank{
    double getSavingsInterestRate(){
        return(4.0);
    }

    double getFixedDepositInterestRate(){
        return(8.5);
    }
}
