public class FirstClass extends Compartment{
    public String notice(){
        return "First Class Compartment";
    }
}
