public class Luggage extends Compartment{
    public String notice(){
        return "Luggage Compartment";
    }
}
