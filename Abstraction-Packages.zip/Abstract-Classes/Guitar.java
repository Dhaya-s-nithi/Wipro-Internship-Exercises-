public class Guitar extends Instrument{
    void play(){
        System.out.println("Guitar is playing tin tin tin");
    }
}
