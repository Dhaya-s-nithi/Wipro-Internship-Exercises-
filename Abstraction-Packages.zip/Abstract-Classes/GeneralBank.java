public abstract class GeneralBank{
    abstract double getSavingsInterestRate();
    abstract double getFixedDepositInterestRate();
}
