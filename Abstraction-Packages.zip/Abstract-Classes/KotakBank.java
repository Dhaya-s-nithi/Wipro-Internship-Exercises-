class KotakBank extends GeneralBank{
    double getSavingsInterestRate(){
        return(6.0);
    }

    double getFixedDepositInterestRate(){
        return(9.0);
    }
}
