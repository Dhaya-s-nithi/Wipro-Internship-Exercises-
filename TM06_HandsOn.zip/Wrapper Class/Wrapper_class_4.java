package com.wipro.internship;

public class Wrapper_class_4 implements Cloneable {
	private String name;
	
	public Wrapper_class_4(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	@Override
	public Wrapper_class_4 clone() {
		try {
			return (Wrapper_class_4) super.clone();
		} catch (CloneNotSupportedException e) {
			System.out.println("Cloning Not Allowed");
			return this;
		}		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Wrapper_class_4 emp = new Wrapper_class_4("Praveen Kumar P");
		Wrapper_class_4 empClone = emp.clone();
		
		empClone.setName("ppk");
		
		System.out.println(emp.getName());
		System.out.println(empClone.getName());
	}

}
