package com.wipro.internship;

import java.util.ArrayList;

public class Lambda_2 {
	public static void main(String[] args) {
		ArrayList<String> l = new ArrayList<String>();
		l.add("Python");
		l.add("C");
		l.add("Java");
		l.add("HTML");
		l.add("CSS");
		l.add("MySQL");
		l.add("C++");
		l.add("JavaScript");
		l.add("Linux");
		l.add("Oracle");
		l.forEach(word -> {
			String x="";
			for(int i=word.length()-1;i>=0;i--) {
				x+=word.charAt(i);
			}
			System.out.println(x);
		});
	}
}
