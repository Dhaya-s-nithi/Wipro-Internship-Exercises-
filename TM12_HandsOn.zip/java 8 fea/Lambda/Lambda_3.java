package com.wipro.internship;

import java.util.ArrayList;
import java.util.Arrays;

public class Lambda_3 {

	public static void main(String[] args) {
		ArrayList<String> l = new ArrayList<String>(
				Arrays.asList("Java", "Python", "C++", "C", "JavaScript", "Go", "Rust", "Bash", "Haskell", "Ruby"));
		
		l.forEach(word -> System.out.print((word.length() % 2 != 0) ? word + " " : ""));

	}

}