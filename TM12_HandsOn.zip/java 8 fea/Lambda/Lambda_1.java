package com.wipro.internship;

import java.util.ArrayList;
import java.util.Random;

public class Lambda_1 {

	public static void main(String[] args) {
		ArrayList<Integer> l = new ArrayList<Integer>();
		Random random = new Random();
		for(int i = 0; i < 25; i++){
			l.add(random.nextInt(100));
		}
		System.out.println("Array : " +l.toString());
		System.out.print("Prime Nos : ");
		l.forEach(num -> {
			int f=0;
			for (int i = 2; i <= (int) Math.sqrt(num); i++) {
				if (num % i == 0) {
					f++;
				}
			}
			if (f==0) {
				System.out.print(num + " ");
			}
		});
	}

}
