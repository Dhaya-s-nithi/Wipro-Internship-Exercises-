package com.wipro.internship;

import java.util.Optional;

class Employeee {
	String empNo;
	String name;	
}

class InvalidEmployeeException extends Exception{
	public InvalidEmployeeException(String s){
		super(s);
	}
}

public class Optional_Class_3 {

	public static void main(String[] args) throws InvalidEmployeeException {
		// TODO Auto-generated method stub
		Employeee e = new Employeee();
		e=null;
		Optional<Employeee> n = Optional.ofNullable(e);
		
		System.out.println(n.orElseThrow(() -> new InvalidEmployeeException("InvalidEmployeeException has occured")));
	}

}
