package com.wipro.internship;

import java.util.Optional;

public class Optional_Class_2 {
	String address;
	String default_address = "India";

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Optional_Class_2 obj = new Optional_Class_2();
		Optional<String> n = Optional.ofNullable(obj.address);
		
		//System.out.println(n.orElse(obj.default_address));
		if(n.isPresent())
			System.out.println(n.get());
		else
			System.out.println(obj.default_address);
	}

}