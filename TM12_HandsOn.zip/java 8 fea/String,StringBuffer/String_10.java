package com.wipro.internship;
import java.util.Scanner;

public class String_10 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a = sc.nextLine();
		int n=sc.nextInt();
		String b=a.substring(a.length()-n, a.length());
		for(int i=0;i<n;i++)
			System.out.print(b);
	}
}
