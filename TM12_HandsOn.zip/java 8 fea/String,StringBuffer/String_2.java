package com.wipro.internship;
import java.util.*;

public class String_2 {
	static String concatenate(String str1, String str2) {
		String ans = "";
		if (str1.charAt(str1.length()-1) == str2.charAt(0))
			ans = str1.substring(0, str1.length()-1) + str2;
		else
			ans = str1 +" " + str2;
		
		return ans.toLowerCase();
	}
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the 1st string: ");
		String str1 = sc.nextLine();
		System.out.print("Enter the 2nd string: ");
		String str2 = sc.nextLine();
	
		System.out.println(concatenate(str1, str2));
		
	}

}
