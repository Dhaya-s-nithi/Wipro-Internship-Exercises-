package com.wipro.internship;
import java.util.*;

public class String_1 {

	public static void main(String[] args) {
		
		Scanner sc= new Scanner(System.in);
		String a=sc.nextLine(),b="";
		for(int i=a.length()-1;i>=0;i--) {
			b=b+a.charAt(i);
		}
		System.out.println(a+" "+b);
		if (a.equals(b)) {
			System.out.println(a+" is a palindrome");
		}
		else
			System.out.println(a+" is not a palindrome");
	}
}
