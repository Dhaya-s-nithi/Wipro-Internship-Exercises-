package com.wipro.internship;
import java.util.*;

public class String_6 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the 1st string: ");
		String a = sc.nextLine();
		System.out.print("Enter the 2nd string: ");
		String b = sc.nextLine();
		if(a.length()>b.length())
			System.out.println(b+a+b);
		else
			System.out.println(a+b+a);
	}

}
