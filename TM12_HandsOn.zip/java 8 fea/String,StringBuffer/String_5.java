package com.wipro.internship;
import java.util.*;

public class String_5 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		
		System.out.print("Enter the string: ");
		String str = sc.nextLine();
		
		System.out.println(str.substring(1, str.length()-1));

	}

}
