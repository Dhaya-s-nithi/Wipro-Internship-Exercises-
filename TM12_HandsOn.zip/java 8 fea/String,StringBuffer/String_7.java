package com.wipro.internship;
import java.util.Scanner;

public class String_7 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a = sc.nextLine();
		if (a.charAt(0)=='x' &&a.charAt(a.length()-1)=='x') {
			System.out.println(a.substring(1, a.length()-1));
		}
		else
			System.out.println(a);
	}
}
