package com.wipro.internship;
import java.util.Scanner;

public class String_9 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		String a = sc.nextLine();
		String b = sc.nextLine();
		String c,d;
		int n;
		if (a.length()==b.length()) {
			n=a.length();
			c=a;
			d=b;
		}
		else if (a.length()<b.length()) {
			n=a.length();
			c=a;
			d=b;
		}
		else {
			n=b.length();
			c=b;
			d=a;
		}
		System.out.println(c+" "+d+" "+n);
		for(int i=0;i<n;i++) {
			System.out.print(c.charAt(i));
			System.out.print(d.charAt(i));
		}
		if (a.length()!=b.length())
			System.out.println(d.substring(c.length(), d.length()));
	}
}
