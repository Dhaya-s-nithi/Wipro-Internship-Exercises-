package com.wipro.internship;

import java.util.ArrayList;
import java.util.function.Function;

class Employee2{
	private int empNo;
	private String name;
	private int age;
	private String location;
	
	Employee2(int empNo,String name,int age,String location){
		this.empNo=empNo;
		this.name=name;
		this.age=age;
		this.location=location;
	}
	String getLocation(){
		return location;
	}
	public String toString(){
		return "Employee No: "+empNo+" name="+name+" age="+age+" location="+location;
	}
	
}

public class Functional_Interface_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee2> list = new ArrayList<>();
		list.add(new Employee2(101, "Sachin", 35, "Jaipur"));
		list.add(new Employee2(102, "Kohli", 40, "Pune"));
		list.add(new Employee2(103, "Dhoni", 30, "Ranchi"));
		list.add(new Employee2(104, "Raina", 25, "Kanpur"));
		list.add(new Employee2(105, "Rahul", 29, "Lucknow"));
		
		Function<ArrayList<Employee2>, ArrayList<String>> func = ( all )-> {
			ArrayList<String> locations = new ArrayList<>();
			for(Employee2 e : all){
				locations.add(e.getLocation());
			}
			return locations;
		};
		
		System.out.println(func.apply(list));
	}

}

