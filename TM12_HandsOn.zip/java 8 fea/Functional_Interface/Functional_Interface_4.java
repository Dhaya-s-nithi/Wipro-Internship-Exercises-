package com.wipro.internship;

import java.util.ArrayList;
import java.util.function.Predicate;

class Employee3 {
	private int id;
	private String name;
	private double salary;
	Employee3(int id,String name, double salary){
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	public double getSalary(){
		return salary;
	}
	public String getName(){
		return name;
	}
}

public class Functional_Interface_4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Employee3> list = new ArrayList<>();
		list.add(new Employee3(101,"Sachin",20000));
		list.add(new Employee3(102,"Kohli",5000));
		list.add(new Employee3(103,"Dhoni",58000));
		list.add(new Employee3(104,"Raina",97000));
		list.add(new Employee3(105,"Rahul",40000));
		list.add(new Employee3(104,"Rohit",9800));
		list.add(new Employee3(105,"Mohit",9000));
		
		Predicate<Double> p = i -> i < 10000;
		ArrayList<String> res = new ArrayList<>();
		list.forEach(
		i -> {
			if(p.test(i.getSalary()))res.add(i.getName());
			}
		);
		System.out.println(res);
	}
}
