package com.wipro.internship;

import java.time.LocalDate;
import java.time.Period;

public class Date_Time_API_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate joiningDate = LocalDate.of(2022,3,9);
		Period d = Period.between(joiningDate,LocalDate.now());
		int days = d.getDays(); 
		int months = d.getMonths(); 
		int years = d.getYears();
		System.out.println("Experience : " + years + " years " + months + " months " + days + " days." );
	}

}
