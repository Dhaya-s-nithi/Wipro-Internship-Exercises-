package com.wipro.internship;

import java.time.LocalDate;

public class Date_Time_API_1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LocalDate date = LocalDate.now();
		System.out.println("Todays Date : " + date);
		System.out.println("Date after 10 days : " + date.plusDays(10));
	}

}