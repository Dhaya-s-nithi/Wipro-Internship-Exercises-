import java.util.Scanner;

public class Assignment17 {

	public static void main(String[] args) {
	
		int n;
		int sum=0,rem;
    Scanner sc=new Scanner(System.in);
    System.out.println("Enter your number");
    n=sc.nextInt();
    int temp=n;
    while(n>0)
    {
     rem=n%10;
     sum=(sum*10)+rem;
     n=n/10;
    }
    if(temp==sum)
    {
     System.out.println("Number is Palindrome");	
    }
    else
    {
    	System.out.println("Number is not Palidrome");
    }
	}

}
