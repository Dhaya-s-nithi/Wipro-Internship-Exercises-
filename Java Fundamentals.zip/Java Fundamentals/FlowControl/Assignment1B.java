package Assignment2;
import java.util.Scanner;

public class Assignment2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your first number");
		int a=sc.nextInt();
		System.out.println("Enter your second number");
		int b=sc.nextInt();
		int c=a%10;
		int d=b%10;
		if(c==d)
		{
			System.out.println("True");
		}
		else
		{
			System.out.println("False");
		}
	}

}
