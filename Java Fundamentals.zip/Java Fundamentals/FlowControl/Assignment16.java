import java.util.Scanner;

public class Assignment16 {

	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
		int rem;
		int sum=0;
       System.out.println("Enter your number");		
        int n=sc.nextInt();
        while(n>0)
        {
        	rem=n%10;
            sum=(sum*10)+rem;
            n=n/10;
       }
        System.out.println("Reverse of given number is="+sum);
	}

}
