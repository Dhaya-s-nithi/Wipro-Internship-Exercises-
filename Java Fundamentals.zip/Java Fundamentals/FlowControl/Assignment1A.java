import java.util.Scanner;

public class Assignment1A {

	public static void main(String[] args) {
	
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your number");
       int n=sc.nextInt();
       if(n<0)
       {
    	   System.out.println("Number is Negative");
       }
       else if(n==0)
       {
    	   System.out.println("Number is Zero");
       }
       else
       {
    	   System.out.println("Number is Positive");
       }
	}

}
