public class Programm9 {

	 	public static int[] withoutTen(int[] arr) {
		int n = arr.length;
		int[] temp = new int[n];
		int j = 0;
		
		for (int i=0; i<n; i++)

			if (arr[i] != 10) {

				temp[j] = arr[i];
				j++;
			}
		return temp;
	}

	public static void main(String[] args) {
		int[] arr = {1,99,10};
		int[] res = withoutTen(arr);
		for (int i=0; i<res.length; i++) {
			System.out.print(res[i]+" ");

		}

	}

}
