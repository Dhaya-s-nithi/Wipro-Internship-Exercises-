import java.util.Scanner;

public class Programm3 {
	public static int get(int[] array, int num) {
		for (int i = 0; i < array.length; i++) {
			if (array[i] == num) {
				return (i);
			}
		}
		return (-1);
	}
     public static void main(String[]args)   {	
	Scanner input = new Scanner(System.in);
	System.out.println("Enter array values: ");
	int arr[] = new int[5];
	for (int i = 0; i < arr.length; i++) {
		arr[i] = input.nextInt();
	}
	System.out.println("Enter element to find its position: ");
	int element = input.nextInt();
	int index = get(arr, element);
	System.out.println(element + " is found at index : " + index);  
	}

}
