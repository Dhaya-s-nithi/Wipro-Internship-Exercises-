public class Programm10 {
	
	public static int[] evenOdd(int[] arr) {
		int n = arr.length;
		int Even_count = 0;
		int Odd_count = n-1;
		int[] temp = new int[n];
		for(int i=0;i<n;i++) {
			if(arr[i]%2==0) {
				temp[Even_count] = arr[i];
				Even_count++;
			}
			else {
				temp[Odd_count] = arr[i];
				Odd_count--;
			}
		}
		return temp;
	}

	public static void main(String[] args) {
		
		
		int[] arr = {2,3,2,7,5,6};
		int[] result = evenOdd(arr);
		for(int i=0;i<result.length;i++) {
			System.out.print(result[i]+" ");
		}	
	}
}
