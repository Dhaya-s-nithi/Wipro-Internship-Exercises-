
public class Programm11 {
	
	public static boolean only14(int[] arr) {
		int n = arr.length;
		for(int i=0;i<n;i++) {
			if(arr[i]!=4 ) {
				if(arr[i]!=1)
				return false;
			}
		}
		return true;
	}

	public static void main(String[] args) {
		int[] arr = {1,4,2,4};
		System.out.println(only14(arr));

	}

}
