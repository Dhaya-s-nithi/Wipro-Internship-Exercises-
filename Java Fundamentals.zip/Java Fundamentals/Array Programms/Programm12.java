public class Programm12 {
	
	public static int[] middleWay(int[] a, int[] b) {
		int[] temp = new int[2];
		temp[0] = a[1];
		temp[1] = b[1];
		return temp;
}

	public static void main(String[] args) {
			int[] Arr = {5,2,9};
			int[] Brr = {1,4,5};
			
			int[] arr = middleWay(Arr,Brr);
			for(int i=0;i<2;i++) {
			System.out.print(arr[i]+" ");
			}

	}

}
