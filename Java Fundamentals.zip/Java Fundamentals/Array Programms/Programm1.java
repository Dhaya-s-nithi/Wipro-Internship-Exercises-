
public class Programm1 {

	public static void main(String[] args) {
		
	int a[]= {1,2,3,4,5,6,7};
	int n=a.length;
    int sum=0;
    double average;;
    for(int i=0;i<a.length;i++)
    {
    	sum=sum+a[i];
    }
    System.out.println("Sum="+sum);
    average=sum/n;
    System.out.println("Average ="+average);
	}

}
