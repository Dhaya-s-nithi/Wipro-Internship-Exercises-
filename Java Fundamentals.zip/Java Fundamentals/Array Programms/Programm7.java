import java.util.Scanner;

public class Programm7 {

	public static void main(String[] args) {
     Scanner sc=new Scanner(System.in);
     System.out.println("Enter your size");
     int size=sc.nextInt();
     int j=0;
     int a[]=new int[size];
     System.out.println("Enter your array");
     for(int i=0;i<a.length;i++)
     {
    	 a[i]=sc.nextInt();
     }
     if(size==0||size==1)
     {
    	 System.out.println(size);
     }
     
     for (int i=0; i < size-1; i++){  
         if (a[i] != a[i+1]){  
             a[j++] = a[i];  
         }  
     } 
     a[j++] = a[size-1];
     int q=j;
     for (int i=0; i<q; i++)  
         System.out.print(a[i]+" ");  
}

}
