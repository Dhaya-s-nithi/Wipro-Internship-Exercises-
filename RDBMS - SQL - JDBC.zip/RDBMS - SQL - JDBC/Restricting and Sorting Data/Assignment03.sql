select last_name, salary from employees 
where salary not between  5000 and 12000;