public class String5{
    public static void main(String[] args) {
        System.out.println(args[0].substring(1, args[0].length() - 1));
    }
}
